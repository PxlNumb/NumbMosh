#!/usr/bin/env python3
"""
Datamosher for Fusion - core engine (phase 1)

Real bitstream datamoshing: the video is encoded to raw MPEG-4 Part 2 (no B-frames),
the stream is edited at the VOP (frame) level, then decoded again. Removing an I-frame
makes the following P-frames apply their motion vectors to the previous picture, which
is the classic datamosh look.

Effects in this phase:  void, classic, bloom, repeat
Inspired by the effects of Datamosher-Pro (Akascape, MIT), tomato.py, pymosh and FFglitch.
This is an independent re-implementation of the idea; it does not include FFglitch.

Requires: Python 3.8+ (stdlib only) and an ffmpeg executable
(PATH, or env var DATAMOSH_FFMPEG, or the pip package imageio-ffmpeg).
"""
import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile

VERSION = "0.1.0"
START_CODE = b"\x00\x00\x01"
I_FRAME, P_FRAME, B_FRAME = 0, 1, 2


# ----------------------------------------------------------------- ffmpeg utils
def find_ffmpeg():
    env = os.environ.get("DATAMOSH_FFMPEG")
    if env and os.path.isfile(env):
        return env
    path = shutil.which("ffmpeg")
    if path:
        return path
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return None


def run(cmd, capture=False):
    res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if res.returncode != 0:
        tail = res.stderr.decode("utf-8", "replace")[-1500:]
        raise RuntimeError("ffmpeg failed:\n" + tail)
    return res.stderr.decode("utf-8", "replace") if capture else None


def probe_fps(ffmpeg, src):
    res = subprocess.run([ffmpeg, "-hide_banner", "-i", src],
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    text = res.stderr.decode("utf-8", "replace")
    m = re.search(r"(\d+(?:\.\d+)?)\s*fps", text)
    if not m:
        m = re.search(r"(\d+(?:\.\d+)?)\s*tbr", text)
    return float(m.group(1)) if m else 24.0


def detect_scene_cuts(ffmpeg, src, fps, threshold):
    """Frame numbers where a scene change is detected (used by 'void')."""
    cmd = [ffmpeg, "-hide_banner", "-i", src, "-an", "-r", str(fps),
           "-vf", "select='gt(scene,%s)',showinfo" % threshold, "-f", "null", "-"]
    text = run(cmd, capture=True)
    frames = []
    for m in re.finditer(r"pts_time:\s*([0-9.]+)", text):
        frames.append(int(round(float(m.group(1)) * fps)))
    return sorted(set(f for f in frames if f > 0))


# ----------------------------------------------------------------- m4v parsing
class Frame:
    __slots__ = ("data", "ftype")

    def __init__(self, data, ftype):
        self.data = data
        self.ftype = ftype


def parse_m4v(buf):
    """Split a raw MPEG-4 Part 2 elementary stream into frames.
    Header start codes that precede a VOP (VOS/VO/VOL/GOP/user data) belong to that frame."""
    codes = []
    i = buf.find(START_CODE)
    while i != -1 and i + 3 < len(buf):
        codes.append((i, buf[i + 3]))
        i = buf.find(START_CODE, i + 3)

    frames = []
    cur_start = None
    cur_type = None
    seen_vop = False
    for pos, code in codes:
        if code == 0xB6:  # VOP
            if cur_start is None:
                cur_start = pos
            if seen_vop:
                # two VOPs without headers between them: new frame starts here
                frames.append(Frame(buf[cur_start:pos], cur_type))
                cur_start = pos
            cur_type = (buf[pos + 4] >> 6) & 0x3
            seen_vop = True
        else:
            if code == 0xB1:  # sequence end
                continue
            if seen_vop:
                frames.append(Frame(buf[cur_start:pos], cur_type))
                cur_start, cur_type, seen_vop = pos, None, False
            elif cur_start is None:
                cur_start = pos
    if seen_vop and cur_start is not None:
        end = len(buf)
        frames.append(Frame(buf[cur_start:end], cur_type))
    return frames


# --------------------------------------------------------------------- effects
def fx_void(frames, cuts, **_):
    """Remove every I-frame except the first (cuts become mosh transitions)."""
    return [f for i, f in enumerate(frames) if i == 0 or f.ftype != I_FRAME]


def fx_classic(frames, start, end, **_):
    """Remove the I-frames inside [start, end] (frame numbers)."""
    return [f for i, f in enumerate(frames)
            if i == 0 or not (start <= i <= end and f.ftype == I_FRAME)]


def fx_bloom(frames, start, count, **_):
    """Remove the I-frame at `start`, then repeat the next P-frame `count` times."""
    out = []
    dropped = False
    for i, f in enumerate(frames):
        if i == start and f.ftype == I_FRAME and i > 0:
            dropped = True
            continue
        out.append(f)
        if dropped and f.ftype == P_FRAME:
            out.extend(Frame(f.data, f.ftype) for _ in range(count))
            dropped = False
    return out


def fx_repeat(frames, start, length, count, **_):
    """Repeat the frames [start, start+length) `count` extra times."""
    length = max(1, length)
    seg = frames[start:start + length]
    if not seg:
        return frames
    out = frames[:start + length]
    for _ in range(count):
        out.extend(Frame(f.data, f.ftype) for f in seg)
    out.extend(frames[start + length:])
    return out


# ----------------------------------------------------------------------- main
def build_parser():
    p = argparse.ArgumentParser(description="Datamosher for Fusion - core engine")
    p.add_argument("input", nargs="?")
    p.add_argument("output", nargs="?")
    p.add_argument("--effect", choices=["void", "classic", "bloom", "repeat"], default="void")
    p.add_argument("--start", type=int, default=30, help="first frame of the effect")
    p.add_argument("--end", type=int, default=90, help="last frame (classic)")
    p.add_argument("--length", type=int, default=8, help="frames in the repeated block (repeat)")
    p.add_argument("--count", type=int, default=20, help="number of repetitions (bloom/repeat)")
    p.add_argument("--gop", type=int, default=0,
                   help="classic: insert an I-frame every N frames between start and end")
    p.add_argument("--scene", type=float, default=0.30, help="void: scene-cut sensitivity 0-1")
    p.add_argument("--fps", type=float, default=0.0, help="override frame rate")
    p.add_argument("--quality", type=int, default=3, help="mpeg4 intermediate qscale (1 best - 31)")
    p.add_argument("--codec", choices=["h264", "prores"], default="h264")
    p.add_argument("--keep-length", action="store_true",
                   help="trim/pad the result to the original frame count (for in-place timeline use)")
    p.add_argument("--check", action="store_true", help="print ffmpeg location and exit")
    p.add_argument("--version", action="store_true")
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    if args.version:
        print("datamosh_core", VERSION)
        return 0
    ffmpeg = find_ffmpeg()
    if args.check:
        print(ffmpeg or "FFMPEG_NOT_FOUND")
        return 0 if ffmpeg else 2
    if not ffmpeg:
        print("ERROR: ffmpeg not found. Install it (winget install Gyan.FFmpeg) and restart DaVinci Resolve.")
        return 2
    if not args.input or not args.output:
        print("ERROR: input and output paths are required.")
        return 1
    if not os.path.isfile(args.input):
        print("ERROR: input file does not exist:", args.input)
        return 1

    fps = args.fps or probe_fps(ffmpeg, args.input)
    print("fps:", fps)
    tmp = tempfile.mkdtemp(prefix="datamosh_")
    try:
        # 1) decide where the encoder must place I-frames
        key_frames = set()
        if args.effect == "void":
            key_frames = set(detect_scene_cuts(ffmpeg, args.input, fps, args.scene))
            print("scene cuts detected (frames):", sorted(key_frames))
        elif args.effect in ("classic", "bloom"):
            key_frames.add(args.start)
            if args.effect == "classic" and args.gop > 0:
                k = args.start
                while k <= args.end:
                    key_frames.add(k)
                    k += args.gop
        enc = [ffmpeg, "-y", "-hide_banner", "-i", args.input, "-an", "-r", str(fps),
               "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2,format=yuv420p",
               "-c:v", "mpeg4", "-q:v", str(args.quality), "-g", "100000", "-bf", "0"]
        if key_frames:
            times = ",".join("%.6f" % (k / fps) for k in sorted(key_frames))
            enc += ["-force_key_frames", times]
        raw = os.path.join(tmp, "src.m4v")
        run(enc + ["-f", "m4v", raw])

        # 2) edit the bitstream
        with open(raw, "rb") as fh:
            frames = parse_m4v(fh.read())
        n_i = sum(1 for f in frames if f.ftype == I_FRAME)
        print("frames: %d (I-frames: %d)" % (len(frames), n_i))
        if args.effect != "void" and args.start >= len(frames):
            raise RuntimeError("Start frame %d is past the end of the clip (%d frames)."
                               % (args.start, len(frames)))
        kw = dict(start=args.start, end=args.end, length=args.length,
                  count=args.count, cuts=key_frames)
        fn = {"void": fx_void, "classic": fx_classic,
              "bloom": fx_bloom, "repeat": fx_repeat}[args.effect]
        moshed = fn(frames, **kw)
        if args.keep_length and moshed:
            if len(moshed) > len(frames):
                moshed = moshed[:len(frames)]
            while len(moshed) < len(frames):
                moshed.append(Frame(moshed[-1].data, moshed[-1].ftype))
        print("frames after effect:", len(moshed))
        mosh_path = os.path.join(tmp, "mosh.m4v")
        with open(mosh_path, "wb") as fh:
            for f in moshed:
                fh.write(f.data)

        # 3) decode and re-encode to an editing-friendly file
        dec = [ffmpeg, "-y", "-hide_banner", "-err_detect", "ignore_err",
               "-f", "m4v", "-framerate", str(fps), "-i", mosh_path,
               "-vf", "setpts=N/(%s*TB)" % fps, "-r", str(fps)]
        if args.codec == "prores":
            dec += ["-c:v", "prores_ks", "-profile:v", "3", "-pix_fmt", "yuv422p10le"]
        else:
            dec += ["-c:v", "libx264", "-crf", "14", "-pix_fmt", "yuv420p"]
        try:
            run(dec + [args.output])
        except RuntimeError:
            if args.codec == "h264":  # ffmpeg build without libx264
                run([ffmpeg, "-y", "-hide_banner", "-err_detect", "ignore_err",
                     "-f", "m4v", "-framerate", str(fps), "-i", mosh_path,
                     "-vf", "setpts=N/(%s*TB)" % fps, "-r", str(fps),
                     "-c:v", "mpeg4", "-q:v", "2", args.output])
            else:
                raise
        print("OK:", args.output)
        return 0
    except Exception as exc:  # noqa
        print("ERROR:", exc)
        return 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
