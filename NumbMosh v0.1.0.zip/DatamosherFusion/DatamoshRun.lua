--[[
  Datamosh - shared runner
  M.run(opts) -> output_path | nil, error
    opts.source    string  video file (required)
    opts.effect    number  0 void, 1 classic, 2 bloom, 3 repeat
    opts.start     number  first frame (0-based, in the file)
    opts.length    number  classic: range / repeat: block
    opts.repeats   number  bloom / repeat
    opts.scene     number  void sensitivity 0-1
    opts.prores    boolean ProRes (.mov) instead of H.264 (.mp4)
  Moshed files go to <install>/cache. state.txt remembers moshed -> original.
]]
local M = {}
local IS_WIN = package.config:sub(1, 1) == "\\"

function M.install_dir()
    if IS_WIN then
        return os.getenv("APPDATA") .. "\\Blackmagic Design\\DaVinci Resolve\\Support\\Fusion\\DatamoshFusion\\"
    end
    local home = os.getenv("HOME") or ""
    local mac = home .. "/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/DatamoshFusion/"
    local f = io.open(mac .. "config.txt", "r")
    if f then f:close() return mac end
    return home .. "/.local/share/DaVinciResolve/Fusion/DatamoshFusion/"
end

local function read_file(path)
    local f = io.open(path, "r")
    if not f then return nil end
    local s = f:read("*a")
    f:close()
    return s
end

local function file_exists(path)
    local f = io.open(path, "rb")
    if f then f:close() return true end
    return false
end

local function norm(p) return (p or ""):gsub("\\", "/"):lower() end

local function mkdirs(path)
    if IS_WIN then
        os.execute('if not exist "' .. path .. '" mkdir "' .. path .. '"')
    else
        os.execute('mkdir -p "' .. path .. '"')
    end
end

-- ---- moshed -> original bookkeeping (tab separated lines)
local function load_state()
    local map = {}
    local text = read_file(M.install_dir() .. "state.txt") or ""
    for line in text:gmatch("[^\r\n]+") do
        local a, b = line:match("^(.-)\t(.+)$")
        if a then map[norm(a)] = b end
    end
    return map
end

function M.original_of(path)
    return load_state()[norm(path)]
end

function M.remember(moshed, original)
    local f = io.open(M.install_dir() .. "state.txt", "a")
    if f then f:write(moshed .. "\t" .. original .. "\n") f:close() end
end

-- ---- render
function M.run(opts)
    local dir = M.install_dir()
    local core = dir .. "datamosh_core.py"
    local cfg = read_file(dir .. "config.txt")
    if not cfg or not file_exists(core) then
        return nil, "Not installed correctly. Run the installer again."
    end
    local lines = {}
    for line in cfg:gmatch("[^\r\n]+") do lines[#lines + 1] = line end
    local python, ffmpeg = lines[1], lines[2]
    if not python or python == "" then return nil, "config.txt has no Python path. Run the installer again." end

    local clip = opts.source
    if not clip or clip == "" or not file_exists(clip) then
        return nil, "Source file not found: " .. tostring(clip)
    end
    if clip:match("%.[Dd][Pp][Xx]$") or clip:match("%.[Pp][Nn][Gg]$") or clip:match("%.[Ee][Xx][Rr]$") or clip:match("%.[Tt][Ii][Ff]+$") then
        return nil, "Image sequences are not supported. Use a video file."
    end

    local effects = { "void", "classic", "bloom", "repeat" }
    local effect = effects[math.floor(opts.effect or 0) + 1] or "void"
    local start = math.max(0, math.floor(opts.start or 30))
    local length = math.max(1, math.floor(opts.length or 8))
    local repeats = math.max(1, math.floor(opts.repeats or 20))
    local scene = opts.scene or 0.30
    local ext = opts.prores and ".mov" or ".mp4"
    local name = clip:match("([^/\\]+)$"):gsub("%.[^%.]+$", "")
    local cache = dir .. "cache"
    mkdirs(cache)
    local sep = IS_WIN and "\\" or "/"
    local out = string.format("%s%s%s_mosh_%s_%d%s", cache, sep, name, effect, os.time() % 1000000, ext)
    local log = dir .. "last_run.log"

    local function q(s) return '"' .. s .. '"' end
    local args = string.format("--effect %s --start %d --end %d --length %d --count %d --scene %.2f --codec %s --keep-length",
        effect, start, start + length, length, repeats, scene, opts.prores and "prores" or "h264")

    local cmd
    if IS_WIN then
        local env = ""
        if ffmpeg and ffmpeg ~= "" then env = 'set "DATAMOSH_FFMPEG=' .. ffmpeg .. '" && ' end
        cmd = '"' .. env .. q(python) .. " " .. q(core) .. " " .. q(clip) .. " " .. q(out) .. " " .. args .. " > " .. q(log) .. ' 2>&1"'
    else
        local env = ""
        if ffmpeg and ffmpeg ~= "" then env = "DATAMOSH_FFMPEG=" .. q(ffmpeg) .. " " end
        cmd = env .. q(python) .. " " .. q(core) .. " " .. q(clip) .. " " .. q(out) .. " " .. args .. " > " .. q(log) .. " 2>&1"
    end
    print("[Datamosh] " .. cmd)
    os.execute(cmd)

    if not file_exists(out) then
        return nil, "Render failed. " .. (read_file(log) or "(no log)"):sub(-500)
    end
    return out
end

return M
