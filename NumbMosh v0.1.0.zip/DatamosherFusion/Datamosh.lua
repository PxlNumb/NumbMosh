--[[
  Datamosh  -  Workspace > Scripts > Datamosh   (works from any page)

  Applies datamosh to the clip under the playhead and replaces it IN PLACE
  (MediaPoolItem:ReplaceClip). No new clip, no Loader. The original file is never
  modified or deleted; "Restore" points the clip back to it.

  Requires DaVinci Resolve 18.5+ (ReplaceClip) with scripting available.
  Inspired by Datamosher Pro (Akascape, MIT), tomato.py, pymosh and FFglitch.
]]

local fus = fu or fusion
local dir_ok, M = pcall(function()
    local IS_WIN = package.config:sub(1, 1) == "\\"
    local d
    if IS_WIN then
        d = os.getenv("APPDATA") .. "\\Blackmagic Design\\DaVinci Resolve\\Support\\Fusion\\DatamoshFusion\\"
    else
        local h = os.getenv("HOME") or ""
        d = h .. "/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/DatamoshFusion/"
        local f = io.open(d .. "config.txt", "r")
        if f then f:close() else d = h .. "/.local/share/DaVinciResolve/Fusion/DatamoshFusion/" end
    end
    return dofile(d .. "DatamoshRun.lua")
end)
if not dir_ok then
    print("[Datamosh] Not installed correctly. Run the installer again. " .. tostring(M))
    return
end

-- ------------------------------------------------------------------ Resolve helpers
local function get_ctx()
    local res = (fus and fus.GetResolve and fus:GetResolve()) or (resolve) or (Resolve and Resolve())
    if not res then return nil, "Resolve scripting is not available in this version." end
    local project = res:GetProjectManager():GetCurrentProject()
    local tl = project and project:GetCurrentTimeline()
    if not tl then return nil, "Open a timeline first." end
    local item = tl:GetCurrentVideoItem()
    if not item then return nil, "Put the playhead over a video clip." end
    local mpi = item:GetMediaPoolItem()
    if not mpi then return nil, "This clip has no media (generator/title/compound)." end
    local path = mpi:GetClipProperty("File Path")
    if not path or path == "" then return nil, "Could not read the clip's file path." end
    return { tl = tl, item = item, mpi = mpi, path = path, name = mpi:GetName() }
end

local function playhead_file_frame(ctx)
    local tc = ctx.tl:GetCurrentTimecode() or ""
    local h, m, s, f = tc:match("(%d+)[:;](%d+)[:;](%d+)[:;](%d+)")
    if not h then return nil end
    local fps = tonumber(ctx.tl:GetSetting("timelineFrameRate")) or 24
    local nominal = math.floor(fps + 0.5)
    local abs = ((tonumber(h) * 60 + tonumber(m)) * 60 + tonumber(s)) * nominal + tonumber(f)
    local item_start = ctx.item:GetStart() or 0
    local src_start = 0
    pcall(function() src_start = ctx.item:GetSourceStartFrame() or 0 end)
    return math.max(0, abs - item_start + src_start)
end

-- ------------------------------------------------------------------ window
local ui = fus.UIManager
local disp = bmd.UIDispatcher(ui)

local STYLE = [[
  QWidget { font-size: 13px; }
  QLabel#Title { font-size: 18px; font-weight: bold; }
  QLabel#Clip { color: #9aa0a6; }
  QLabel#Status { color: #c8c8c8; padding: 6px; border: 1px solid #3a3a3a; border-radius: 4px; }
  QPushButton { padding: 7px 12px; border-radius: 4px; }
  QPushButton#Apply { background-color: #d83a3a; color: white; font-weight: bold; padding: 10px; }
  QPushButton#Apply:hover { background-color: #ef4d4d; }
]]

local win = disp:AddWindow({
    ID = "DatamoshWin",
    WindowTitle = "Datamosh",
    Geometry = { 300, 200, 380, 470 },
    StyleSheet = STYLE,
    ui:VGroup{
        Spacing = 8,
        ui:Label{ ID = "Title", Text = "DATAMOSH", Alignment = { AlignHCenter = true } },
        ui:Label{ ID = "Clip", Text = "Clip: -", WordWrap = true, Alignment = { AlignHCenter = true } },
        ui:HGroup{
            Weight = 0,
            ui:Label{ Text = "Effect", Weight = 0.35 },
            ui:ComboBox{ ID = "Effect", Weight = 0.65 },
        },
        ui:HGroup{
            ID = "RowStart", Weight = 0,
            ui:Label{ Text = "Start frame", Weight = 0.35 },
            ui:SpinBox{ ID = "Start", Minimum = 0, Maximum = 999999, Value = 30, Weight = 0.4 },
            ui:Button{ ID = "Playhead", Text = "Playhead", Weight = 0.25 },
        },
        ui:HGroup{
            ID = "RowLength", Weight = 0,
            ui:Label{ Text = "Length", Weight = 0.35 },
            ui:SpinBox{ ID = "Length", Minimum = 1, Maximum = 99999, Value = 8, Weight = 0.65 },
        },
        ui:HGroup{
            ID = "RowRepeats", Weight = 0,
            ui:Label{ Text = "Repeats", Weight = 0.35 },
            ui:SpinBox{ ID = "Repeats", Minimum = 1, Maximum = 999, Value = 20, Weight = 0.65 },
        },
        ui:HGroup{
            ID = "RowSens", Weight = 0,
            ui:Label{ Text = "Sensitivity", Weight = 0.35 },
            ui:Slider{ ID = "Sens", Minimum = 5, Maximum = 95, Value = 30, Orientation = "Horizontal", Weight = 0.5 },
            ui:Label{ ID = "SensVal", Text = "0.30", Weight = 0.15 },
        },
        ui:CheckBox{ ID = "ProRes", Text = "ProRes output (bigger files, safer codec)", Checked = false, Weight = 0 },
        ui:VGap(4),
        ui:Button{ ID = "Apply", Text = "APPLY TO CLIP", Weight = 0 },
        ui:HGroup{
            Weight = 0,
            ui:Button{ ID = "Restore", Text = "Restore original" },
            ui:Button{ ID = "Refresh", Text = "Refresh clip" },
        },
        ui:Label{ ID = "Status", Text = "Ready.", WordWrap = true },
    },
})

local itm = win:GetItems()
itm.Effect:AddItems({ "Void", "Classic", "Bloom", "Repeat" })
itm.Effect.CurrentIndex = 0

local function set_status(text)
    itm.Status.Text = text
    print("[Datamosh] " .. text)
end

local function set_visible(id, v) pcall(function() itm[id].Visible = v end) end

local function refresh_rows()
    local e = itm.Effect.CurrentIndex
    set_visible("RowStart", e ~= 0)
    set_visible("RowLength", e == 1 or e == 3)
    set_visible("RowRepeats", e == 2 or e == 3)
    set_visible("RowSens", e == 0)
end

local function refresh_clip()
    local ctx, err = get_ctx()
    if not ctx then
        itm.Clip.Text = "Clip: -"
        set_status(err)
        return nil
    end
    local orig = M.original_of(ctx.path)
    itm.Clip.Text = "Clip: " .. tostring(ctx.name) .. (orig and "  (moshed)" or "")
    return ctx, orig
end

function win.On.Effect.CurrentIndexChanged(ev) refresh_rows() end
function win.On.Sens.ValueChanged(ev) itm.SensVal.Text = string.format("%.2f", itm.Sens.Value / 100) end
function win.On.Refresh.Clicked(ev) if refresh_clip() then set_status("Ready.") end end

function win.On.Playhead.Clicked(ev)
    local ctx, err = get_ctx()
    if not ctx then set_status(err) return end
    local f = playhead_file_frame(ctx)
    if f then itm.Start.Value = f set_status("Start frame set to " .. f .. ".")
    else set_status("Could not read the playhead timecode.") end
end

function win.On.Apply.Clicked(ev)
    local ctx, orig = refresh_clip()
    if not ctx then return end
    local source = orig or ctx.path          -- always mosh from the original file
    set_status("Rendering... the window may freeze for a moment.")
    local out, err = M.run({
        source = source,
        effect = itm.Effect.CurrentIndex,
        start = itm.Start.Value,
        length = itm.Length.Value,
        repeats = itm.Repeats.Value,
        scene = itm.Sens.Value / 100,
        prores = itm.ProRes.Checked,
    })
    if not out then set_status("Error: " .. tostring(err)) return end
    local ok = ctx.mpi:ReplaceClip(out)
    if ok then
        M.remember(out, source)
        itm.Clip.Text = "Clip: " .. tostring(ctx.name) .. "  (moshed)"
        set_status("Done. Clip replaced in place.")
    else
        set_status("Rendered, but Resolve refused ReplaceClip (needs 18.5+). File: " .. out)
    end
end

function win.On.Restore.Clicked(ev)
    local ctx, orig = refresh_clip()
    if not ctx then return end
    if not orig then set_status("This clip is not a moshed clip.") return end
    if ctx.mpi:ReplaceClip(orig) then
        itm.Clip.Text = "Clip: " .. tostring(ctx.name)
        set_status("Original restored.")
    else
        set_status("Could not restore. Original file: " .. orig)
    end
end

function win.On.DatamoshWin.Close(ev) disp:ExitLoop() end

refresh_rows()
refresh_clip()
win:Show()
disp:RunLoop()
win:Hide()
